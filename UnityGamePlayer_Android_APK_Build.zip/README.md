# Unity Game Player — Android starter

Android Studio project starter. It imports ZIPs, safely extracts them, detects common Unity build types, stores a local game library, opens Unity WebGL `index.html` files in WebView, and hands APK files to Android's installer.

## Build
Open this folder in Android Studio. Use Android SDK 35 and JDK 17, sync Gradle, then Build > Build APK(s).

## Important limitations
A ZIP is not itself a runnable game. Windows Unity builds (`.exe`, `UnityPlayer.dll`, `*_Data`) cannot run natively on Android; they require a compatible Windows translation/emulation layer or PC streaming. This starter does not include one. A WebGL build can run in WebView, but many games require additional WebGL compatibility work. Android APKs are installed/launched through Android's package installer.

Universal touch controls are not yet implemented: Android apps cannot reliably inject joystick/button input into arbitrary other apps. The next stage is a configurable virtual gamepad for WebGL games that accept keyboard/gamepad input, plus per-game control profiles. Native Android APKs generally need their own touch controls or game-specific integration.

## Build an APK without installing Android Studio locally
This repository includes a GitHub Actions workflow at `.github/workflows/android.yml`.
1. Create a GitHub repository and upload the contents of this project (not the outer ZIP file).
2. Open the repository's **Actions** tab.
3. Select **Build Android APK**, then **Run workflow** (or push to `main`).
4. When it finishes, open the workflow run and download the `UnityGamePlayer-debug-apk` artifact.
5. On your Android device, open the downloaded APK and approve installation if Android asks.

This produces a debug APK for testing, not a Play Store release. The build still has the platform limitations described above.
