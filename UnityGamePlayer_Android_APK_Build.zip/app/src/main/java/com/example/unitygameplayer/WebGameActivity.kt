package com.example.unitygameplayer
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.appcompat.app.AppCompatActivity
import java.io.File
class WebGameActivity:AppCompatActivity(){
 override fun onCreate(b:Bundle?){super.onCreate(b);val path=intent.getStringExtra("path")?:return
  val web=WebView(this).apply{settings.javaScriptEnabled=true;settings.domStorageEnabled=true;settings.allowFileAccess=true;webViewClient=WebViewClient()}
  setContentView(FrameLayout(this).apply{addView(web,FrameLayout.LayoutParams(-1,-1))})
  val f=File(path);if(f.exists())web.loadUrl("file://${f.absolutePath}")
 }
}
