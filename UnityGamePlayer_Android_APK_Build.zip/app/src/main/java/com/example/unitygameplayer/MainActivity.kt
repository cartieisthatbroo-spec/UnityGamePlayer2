package com.example.unitygameplayer
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class Game(val name:String,val folder:String,val type:String,val launch:String)
class MainActivity:AppCompatActivity(){
 private val games=mutableListOf<Game>(); private lateinit var list:LinearLayout; private lateinit var status:TextView
 private val prefs by lazy{getSharedPreferences("library",MODE_PRIVATE)}
 private val picker=registerForActivityResult(ActivityResultContracts.OpenDocument()){u->if(u!=null)importZip(u)}
 override fun onCreate(b:Bundle?){super.onCreate(b)
  val root=LinearLayout(this).apply{orientation=1;setPadding(20,24,20,16);setBackgroundColor(0xFF090B13.toInt())}
  root.addView(TextView(this).apply{text="UNITY GAME PLAYER";textSize=25f;setTextColor(-1);gravity=Gravity.CENTER_VERTICAL})
  root.addView(TextView(this).apply{text="Import Unity ZIP games and launch supported builds.";setTextColor(0xFFBBBBCC.toInt());setPadding(0,8,0,16)})
  root.addView(Button(this).apply{text="＋  IMPORT UNITY ZIP";setOnClickListener{picker.launch(arrayOf("application/zip","application/x-zip-compressed","*/*"))}})
  status=TextView(this).apply{setTextColor(0xFFBBBBCC.toInt());setPadding(0,10,0,10)};root.addView(status)
  val sc=ScrollView(this);list=LinearLayout(this).apply{orientation=1};sc.addView(list);root.addView(sc,LinearLayout.LayoutParams(-1,0,1f));setContentView(root)
  val a=JSONArray(prefs.getString("games","[]"));for(i in 0 until a.length()){val o=a.getJSONObject(i);val g=Game(o.getString("name"),o.getString("folder"),o.getString("type"),o.getString("launch"));if(File(g.folder).exists())games.add(g)};render()
 }
 private fun importZip(uri:Uri){status.text="Importing ZIP…";Thread{try{
  val dest=File(filesDir,"games/g${System.currentTimeMillis()}").apply{mkdirs()}
  contentResolver.openInputStream(uri)!!.use{input->java.util.zip.ZipInputStream(input).use{z->var e=z.nextEntry;while(e!=null){
   val out=File(dest,e.name).canonicalFile;require(out.path.startsWith(dest.canonicalPath+File.separator)||out==dest){"Unsafe ZIP entry"}
   if(e.isDirectory)out.mkdirs() else {out.parentFile?.mkdirs();out.outputStream().use{z.copyTo(it)}};z.closeEntry();e=z.nextEntry
  }}}
  val all=dest.walkTopDown().filter{it.isFile}.toList()
  val web=all.firstOrNull{it.name.equals("index.html",true)}
  val apk=all.firstOrNull{it.extension.equals("apk",true)}
  val exe=all.firstOrNull{it.extension.equals("exe",true)}
  val detected=when{web!=null->Triple("Unity WebGL",web.absolutePath,web.name);apk!=null->Triple("Android APK",apk.absolutePath,apk.name);exe!=null&&all.any{it.name.equals("UnityPlayer.dll",true)}->Triple("Windows Unity build",exe.absolutePath,exe.name);all.any{it.name=="globalgamemanagers"}->Triple("Unity data (not directly launchable)",dest.absolutePath,"Unity game");else->Triple("Unknown ZIP",dest.absolutePath,"Imported game")}
  val g=Game(detected.third,dest.absolutePath,detected.first,detected.second);runOnUiThread{games.add(g);save();status.text="Imported: ${g.type}";render()}
 }catch(e:Exception){runOnUiThread{status.text="Import failed: ${e.message}"}}}.start()}
 private fun save(){val a=JSONArray();games.forEach{a.put(JSONObject().put("name",it.name).put("folder",it.folder).put("type",it.type).put("launch",it.launch))};prefs.edit().putString("games",a.toString()).apply()}
 private fun render(){list.removeAllViews();if(games.isEmpty())list.addView(TextView(this).apply{text="Your library is empty. Import a ZIP to begin.";setTextColor(0xFFBBBBCC.toInt());setPadding(4,24,4,24)})
  games.toList().forEach{g->val box=LinearLayout(this).apply{orientation=1;setPadding(14,12,14,12);setBackgroundColor(0xFF191C2B.toInt())}
   box.addView(TextView(this).apply{text=g.name;textSize=18f;setTextColor(-1)})
   box.addView(TextView(this).apply{text=g.type;textSize=12f;setTextColor(0xFFBBBBCC.toInt());setPadding(0,5,0,8)})
   box.addView(Button(this).apply{text=when(g.type){"Unity WebGL"->"PLAY";"Android APK"->"INSTALL APK";"Windows Unity build"->"WINDOWS BUILD — NOT NATIVE";else->"NOT PLAYABLE ON ANDROID YET"};setOnClickListener{launch(g)}})
   box.addView(Button(this).apply{text="REMOVE";setOnClickListener{games.remove(g);save();render()}})
   list.addView(box,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=12})
  }
 }
 private fun launch(g:Game){when(g.type){
  "Unity WebGL"->startActivity(Intent(this,WebGameActivity::class.java).putExtra("path",g.launch))
  "Android APK"->{val u=FileProvider.getUriForFile(this,"$packageName.provider",File(g.launch));startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(u,"application/vnd.android.package-archive").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))}
  "Windows Unity build"->status.text="Windows .exe games need a compatible Windows emulation layer or PC streaming; Android cannot run them natively."
  else->status.text="This ZIP does not contain a directly playable Android/WebGL build."
 }}
}
